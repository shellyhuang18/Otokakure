package com.example.naseeb96.pitchdetector;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import be.tarsos.dsp.AudioDispatcher;
import be.tarsos.dsp.AudioEvent;
import be.tarsos.dsp.AudioProcessor;
import be.tarsos.dsp.io.android.AudioDispatcherFactory;
import be.tarsos.dsp.pitch.PitchDetectionHandler;
import be.tarsos.dsp.pitch.PitchDetectionResult;
import be.tarsos.dsp.pitch.PitchProcessor;


public class MainActivity extends AppCompatActivity {
    TextView hertzText;
    TextView noteText;
    TextView octaveText;
    TextView halfStepText;
    public String[] letterNoteArray =  {"A","A#","B","C","C#","D","D#","E","F","F#","G","G#"};
    AudioDispatcher dispatcher = AudioDispatcherFactory.fromDefaultMicrophone(22050,1024,0);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        hertzText = (TextView) findViewById(R.id.Hertz);
        noteText = (TextView) findViewById(R.id.letterNote);
        octaveText = (TextView) findViewById(R.id.Octaves);
        halfStepText = (TextView) findViewById(R.id.halfSteps);
        PitchDetectionHandler pdh = new PitchDetectionHandler() {
            @Override
            public void handlePitch(PitchDetectionResult res, AudioEvent e){
                final float pitchInHz = res.getPitch();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        getPitch(pitchInHz);
                    }
                });
            }
        };
        AudioProcessor pitchProcessor = new PitchProcessor(PitchProcessor.PitchEstimationAlgorithm.FFT_YIN, 22050, 1024, pdh);
        dispatcher.addAudioProcessor(pitchProcessor);

        Thread audioThread = new Thread(dispatcher, "Audio Thread");
        audioThread.start();
    }
    public void getPitch(float pitchInHz) {
        hertzText.setText("" + pitchInHz);
        // Base Note is A4 = 440
        final float baseNote = 440;
        // octaves from base -> octaves  =  log(base2)(freq/base).
        double octavesFromBase = Math.round((Math.log((pitchInHz/baseNote))/Math.log(2)));
        // half steps = log2^12 (freq/base)
        //double halfStepsFromBase = (Math.log((pitchInHz/baseNote))/Math.log(a));
        // half steps from base -> half steps  =  12 * log(base2)(freq/base).
        double halfStepsFromBase = Math.round(12 * (Math.log((pitchInHz/baseNote))/Math.log(2)));
        octaveText.setText("" + octavesFromBase);
        halfStepText.setText("" + halfStepsFromBase);
        int letterNoteIndex = ((int) halfStepsFromBase % 12);
        if (letterNoteIndex < 0)
            letterNoteIndex += 12;
        int numberNote;
        int other = (int)halfStepsFromBase / 12;
        if (halfStepsFromBase < 3) {
            numberNote = (int)halfStepsFromBase / 12 + 4;
        } else {
            numberNote = (int)halfStepsFromBase / 12 + 5;
        }
        noteText.setText(letterNoteArray[letterNoteIndex] + numberNote);
    }
}
